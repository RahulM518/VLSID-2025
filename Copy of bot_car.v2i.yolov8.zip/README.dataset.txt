# bot_car > 2024-12-16 12:54am
https://universe.roboflow.com/customrobot/bot_car

Provided by a Roboflow user
License: Public Domain

