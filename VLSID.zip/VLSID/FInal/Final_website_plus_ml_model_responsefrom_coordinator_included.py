from flask import Flask, render_template_string, request, jsonify, Response
import threading
import time
import cv2
from ultralytics import YOLO

app = Flask(__name__)

# YOLOv8 model
model = YOLO('best.pt')

# Camera stream
CAMERA_URL = "http://192.168.82.160:8080/video"  # Replace with your camera URL
cap = cv2.VideoCapture(CAMERA_URL)

# Task and RFID Command State
tasks = []
current_command = "None"  # Stores the latest RFID command
task_counter = 1

# Add tasks with auto-delete logic
def add_task_to_list(task_name):
    global task_counter
    task = {'id': task_counter, 'task_name': task_name, 'created_at': time.time()}
    tasks.append(task)
    task_counter += 1

def auto_delete_tasks():
    while True:
        time.sleep(1)
        current_time = time.time()
        tasks[:] = [task for task in tasks if current_time - task['created_at'] < 15]

# Video stream generator
def generate_frames():
    desired_fps = 2
    frame_interval = 1 / desired_fps
    last_frame_time = time.time()

    while True:
        current_time = time.time()
        if current_time - last_frame_time < frame_interval:
            continue

        for _ in range(5):  # Skip buffered frames for real-time performance
            cap.grab()

        ret, frame = cap.read()
        if not ret:
            break

        # YOLO Detection
        results = model(frame)
        detections = results[0]
        detections = detections[detections.boxes.conf > 0.8]
        frame = detections.plot()

        ret, buffer = cv2.imencode('.jpg', frame)
        if not ret:
            continue

        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
        last_frame_time = current_time

# Flask routes
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Stream and Motor Control</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .container { display: flex; }
        .video { margin-right: 20px; }
        ul { list-style-type: none; padding: 0; }
        li { margin: 10px 0; }
    </style>
</head>
<body>
    <h1>Live Video Stream & Motor Control</h1>
    <div class="container">
        <div class="video">
            <h2>Video Stream</h2>
            <img src="{{ url_for('video_feed') }}" width="640" height="480">
        </div>
        <div>
            <h2>RFID Commands</h2>
            <p>Last Command: <strong id="last-command">None</strong></p>
            <button onclick="sendMotorCommand('move_forward')">Move Forward</button>
            <button onclick="sendMotorCommand('turn_left')">Turn Left</button>
            <button onclick="sendMotorCommand('turn_right')">Turn Right</button>
            <button onclick="sendMotorCommand('stop')">Stop</button>
            <h2>Tasks</h2>
            <form id="task-form">
                <input type="text" name="task" placeholder="New Task" required>
                <button type="submit">Add Task</button>
            </form>
            <ul id="task-list"></ul>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function fetchLastCommand() {
            $.get("/rfid_command", function(data) {
                $("#last-command").text(data.command || "None");
            });
        }

        function fetchTasks() {
            $.get("/tasks", function(data) {
                const taskList = $("#task-list").empty();
                data.tasks.forEach(task => {
                    taskList.append(`
                        <li>
                            ${task.task_name}
                            <button onclick="deleteTask(${task.id})">Delete</button>
                        </li>
                    `);
                });
            });
        }

        function deleteTask(id) {
            $.ajax({ url: `/delete_task/${id}`, type: "DELETE", success: fetchTasks });
        }

        function sendMotorCommand(action) {
            $.post(`/motor_control/${action}`, function(data) {
                alert(data.message);
            });
        }

        $(document).ready(() => {
            fetchLastCommand();
            fetchTasks();
            setInterval(fetchLastCommand, 3000);
            setInterval(fetchTasks, 5000);

            $("#task-form").on("submit", function(e) {
                e.preventDefault();
                const task = $(this).find("input[name='task']").val();
                if (task) {
                    $.post("/add_task", { task }, fetchTasks);
                    $(this)[0].reset();
                }
            });
        });
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/rfid_command', methods=['POST', 'GET'])
def rfid_command():
    global current_command
    if request.method == 'POST':
        current_command = request.data.decode('utf-8')
        return jsonify({'message': 'Command received', 'command': current_command})
    return jsonify({'command': current_command})

@app.route('/motor_control/<action>', methods=['POST'])
def motor_control(action):
    return jsonify({'message': f'Motor command "{action}" executed'})

@app.route('/tasks', methods=['GET'])
def get_tasks():
    return jsonify({'tasks': tasks})

@app.route('/add_task', methods=['POST'])
def add_task():
    task_name = request.form.get('task')
    if task_name:
        add_task_to_list(task_name)
        return jsonify({'message': 'Task added'})
    return jsonify({'message': 'No task name provided'}), 400

@app.route('/delete_task/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    global tasks
    tasks = [task for task in tasks if task['id'] != task_id]
    return jsonify({'message': 'Task deleted'})

if __name__ == '__main__':
    threading.Thread(target=auto_delete_tasks, daemon=True).start()
    app.run(host='0.0.0.0', port=5000, debug=True)
