from flask import Flask, render_template_string, request, jsonify, Response
import cv2
from ultralytics import YOLO
import time
import threading

app = Flask(__name__)

# Camera URL (your MJPEG stream)
CAMERA_URL = "http://192.168.82.160:8080/video"

# Load YOLOv8 model
model = YOLO('best.pt')

# Initialize video capture
cap = cv2.VideoCapture(CAMERA_URL)

# Task Management
tasks = []
task_counter = 1

# Add task creation time to handle deletion timing
def add_task_to_list(task_name):
    global task_counter
    task = {'id': task_counter, 'task_name': task_name, 'created_at': time.time()}
    tasks.append(task)
    task_counter += 1

# Auto delete task logic based on creation time
def auto_delete_tasks():
    while True:
        time.sleep(1)
        current_time = time.time()
        tasks_to_delete = [task for task in tasks if current_time - task['created_at'] >= 15]
        for task in tasks_to_delete:
            tasks.remove(task)

# Video stream generator
def generate_frames():
    desired_fps = 2
    frame_interval = 1 / desired_fps  # Time between frames in seconds
    last_frame_time = time.time()

    while True:
        # Ensure we only process frames at the desired FPS
        current_time = time.time()
        if current_time - last_frame_time < frame_interval:
            continue  # Skip frame processing to maintain FPS

        # Drop stale frames to ensure real-time performance
        for _ in range(5):  # Adjust this if needed based on camera buffering
            cap.grab()

        ret, frame = cap.read()
        if not ret:
            break

        # Process the frame with YOLOv8
        results = model(frame)
        detections = results[0]
        detections = detections[detections.boxes.conf > 0.8]
        frame = detections.plot()

        # Encode the processed frame to JPEG format
        ret, buffer = cv2.imencode('.jpg', frame)
        if not ret:
            continue

        # Generate the frame bytes for the MJPEG stream
        frame_bytes = buffer.tobytes()

        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')

        # Update the time of the last processed frame
        last_frame_time = time.time()

# HTML Template
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Stream and Task Management</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .container { display: flex; }
        .video { margin-right: 20px; }
        .tasks { margin: 10px 0; }
        button { margin: 5px; padding: 5px 10px; cursor: pointer; }
    </style>
</head>
<body>
    <h1>Live Video Stream and Task Management</h1>
    <div class="container">
        <div class="video">
            <h2>Live Video Stream</h2>
            <img src="{{ url_for('video_feed') }}" width="640" height="480">
        </div>
        <div>
            <h2>Task List</h2>
            <form id="task-form">
                <input type="text" name="task" placeholder="Enter new task" required>
                <button type="submit">Add Task</button>
            </form>
            <ul id="task-list"></ul>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        let tasks = [];

        function fetchTasks() {
            $.get("/tasks", function(data) {
                tasks = data.tasks;
                renderTasks();
            });
        }

        function renderTasks() {
            const taskList = $('#task-list');
            taskList.empty();
            tasks.forEach(task => {
                taskList.append(`
                    <li>
                        ${task.task_name}
                        <button onclick="deleteTask(${task.id})">Delete</button>
                    </li>
                `);
            });
        }

        function deleteTask(taskId) {
            $.ajax({
                url: `/delete_task/${taskId}`,
                method: 'DELETE',
                success: fetchTasks
            });
        }

        $(document).ready(function() {
            fetchTasks();

            $('#task-form').on('submit', function(event) {
                event.preventDefault(); // Prevent page reload
                const task = $(this).find('input[name="task"]').val();
                if (task) {
                    $.post("/add_task", { task }, function() {
                        fetchTasks(); // Refresh task list
                        $('#task-form')[0].reset(); // Clear input field
                    });
                }
            });

            setInterval(fetchTasks, 3000);
        });
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route('/add_task', methods=['POST'])
def add_task():
    task_name = request.form.get('task')
    if task_name:
        add_task_to_list(task_name)
    return jsonify({'message': 'Task added'})

@app.route('/tasks', methods=['GET'])
def get_tasks():
    return jsonify({'tasks': tasks})

@app.route('/delete_task/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    global tasks
    tasks = [task for task in tasks if task['id'] != task_id]
    return jsonify({'message': 'Task deleted'})

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    # Start the auto-delete task thread
    thread = threading.Thread(target=auto_delete_tasks, daemon=True)
    thread.start()
    # Run the Flask app
    app.run(host='0.0.0.0', port=5000, debug=True)

