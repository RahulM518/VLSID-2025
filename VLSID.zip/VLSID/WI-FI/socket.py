import socket

# Replace with the IP address of your ESP32 (printed on the Serial Monitor)
ESP32_IP = "192.168.x.x"
ESP32_PORT = 8080

def main():
    try:
        # Create a socket object
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect((ESP32_IP, ESP32_PORT))

        print("Connected to ESP32 server")
        
        # Send a message to the ESP32
        message = "Hello, ESP32!\n"
        client_socket.send(message.encode())

        # Receive and print the response
        response = client_socket.recv(1024).decode()
        print("Received from ESP32:", response)

        # Close the connection
        client_socket.close()

    except Exception as e:
        print("Error:", e)

if _name_ == "_main_":
    main()