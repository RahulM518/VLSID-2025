from flask import Flask, render_template_string, request, jsonify

app = Flask(__name__)

# Global Variables
tasks = []
task_counter = 1
GRID_SIZE = 20
grid_state = [['red' for _ in range(GRID_SIZE)] for _ in range(GRID_SIZE)]
is_editable = False

# Home Page
@app.route('/')
def home():
    return render_template_string(HTML_TEMPLATE)

# APIs for Tasks
@app.route('/get_tasks', methods=['GET'])
def get_tasks():
    return jsonify({'tasks': tasks})

@app.route('/add_task', methods=['POST'])
def add_task():
    global tasks, task_counter
    task = request.json.get('task')
    task_id = task_counter
    tasks.append({'id': task_id, 'task': task})
    task_counter += 1
    return jsonify({'id': task_id})

@app.route('/delete_task/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    global tasks
    tasks = [task for task in tasks if task['id'] != task_id]
    return jsonify({'message': 'Task deleted successfully'})

# APIs for Grid
@app.route('/get_grid', methods=['GET'])
def get_grid():
    return jsonify({'grid': grid_state, 'is_editable': is_editable})

@app.route('/update_grid', methods=['POST'])
def update_grid():
    global grid_state
    grid_state = request.json['grid']
    return jsonify({'message': 'Grid updated successfully'})

@app.route('/toggle_edit', methods=['POST'])
# def toggle_edit():
#     global is_editable
#     password = request.json.get('password')
#     if password == 'admin':
#         is_editable = not is_editable
#         if not is_editable:
#             # Print grid to terminal on locking
#             print("Grid Locked. Current State:")
#             for row in grid_state:
#                 print([0 if cell == 'red' else 1 for cell in row])
#         return jsonify({'message': 'Edit mode toggled', 'is_editable': is_editable})
#     else:
#         return jsonify({'message': 'Invalid password'}), 403

@app.route('/toggle_edit', methods=['POST'])
def toggle_edit():
    global is_editable
    password = request.json.get('password')
    if password == 'admin':
        is_editable = not is_editable
        if not is_editable:
            # Print grid to terminal on locking
            print("Grid Locked. Current State:")
            print("Legend:\n. -> Blocked (red)\n# -> Passable (blue)\n")
            
            # Print column headers
            header = "     " + " ".join(f"{col:2}" for col in range(GRID_SIZE))
            print(header)
            
            # Print rows with row numbers and grid content
            for row_index, row in enumerate(grid_state):
                row_content = " ".join('#' if cell == 'red' else '.' for cell in row)
                print(f"{row_index:3}  {row_content}")
            
        return jsonify({'message': 'Edit mode toggled', 'is_editable': is_editable})
    else:
        return jsonify({'message': 'Invalid password'}), 403


# HTML Template
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Task Manager and Editable Grid</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: row;
            align-items: flex-start;
            gap: 20px;
        }
        .task-container, .grid-container {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
        }
        .task-container {
            width: 300px;
        }
        .task-container ul {
            list-style-type: none;
            padding: 0;
        }
        .task-container li {
            margin: 10px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .task-container button {
            margin-left: 10px;
            padding: 5px 10px;
            cursor: pointer;
        }
        .grid-container {
            display: grid;
            grid-template-columns: repeat(20, 1fr); /* 20 tiles per row */
            width: 500px;
            height: 500px;
            border: 1px solid #000;
        }
        .grid-item {
            width: 25px; /* Tile size */
            height: 25px; /* Tile size */
            cursor: pointer;
        }
        .controls {
            margin: 10px 0;
        }
        button {
            margin: 5px;
            padding: 5px 10px;
            cursor: pointer;
        }
        .hidden {
            display: none;
        }
    </style>
</head>
<body>
    <!-- Task Manager -->
    <div class="task-container">
        <h2>Task Manager</h2>
        <input id="task-input" type="text" placeholder="Add a task" />
        <button id="add-task">Add Task</button>
        <ul id="task-list"></ul>
    </div>

    <!-- Editable Grid -->
    <div>
        <div class="controls">
            <button id="edit-button">Edit Grid</button>
            <button id="lock-button" class="hidden">Lock Grid</button>
            <input id="password" type="password" placeholder="Enter password" class="hidden">
        </div>
        <div class="grid-container" id="grid"></div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        let tasks = [];
        let grid = [];
        let isEditable = false;

        // Fetch tasks and grid state from server
        function fetchTasks() {
            $.get("/get_tasks", function(data) {
                tasks = data.tasks;
                renderTasks();
            });
        }

        function fetchGrid() {
            $.get("/get_grid", function(data) {
                grid = data.grid;
                isEditable = data.is_editable;
                renderGrid();
                updateControls();
            });
        }

        // Render task list
        function renderTasks() {
            const taskList = $('#task-list');
            taskList.empty();
            tasks.forEach(task => {
                taskList.append(`
                    <li>
                        ${task.task}
                        <button onclick="deleteTask(${task.id})">Delete</button>
                    </li>
                `);
            });
        }

        // Add and delete tasks
        $('#add-task').click(function() {
            const taskInput = $('#task-input');
            const task = taskInput.val();
            if (task) {
                $.post("/add_task", JSON.stringify({ task }), function(data) {
                    fetchTasks();
                    taskInput.val('');
                }, 'json');
            }
        });

        function deleteTask(taskId) {
            $.ajax({
                url: `/delete_task/${taskId}`,
                method: 'DELETE',
                success: function() {
                    fetchTasks();
                }
            });
        }

        // Render 20x20 grid
        function renderGrid() {
            const gridContainer = $('#grid');
            gridContainer.empty();
            grid.forEach((row, rowIndex) => {
                row.forEach((cellColor, colIndex) => {
                    gridContainer.append(`
                        <div
                            class="grid-item"
                            style="background-color: ${cellColor};"
                            data-row="${rowIndex}"
                            data-col="${colIndex}"
                            onclick="toggleColor(${rowIndex}, ${colIndex})"
                        ></div>
                    `);
                });
            });
        }

        // Toggle cell color
        function toggleColor(row, col) {
            if (!isEditable) return;

            const currentColor = grid[row][col];
            grid[row][col] = currentColor === 'red' ? 'blue' : 'red';
            renderGrid();
        }

        // Save grid state
        function saveGrid() {
            $.ajax({
                url: '/update_grid',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ grid }),
                success: function() {
                    console.log("Grid saved successfully!");
                }
            });
        }

        // Edit mode toggle
        function toggleEditMode() {
            const password = $('#password').val();
            $.ajax({
                url: '/toggle_edit',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ password }),
                success: function(data) {
                    isEditable = data.is_editable;
                    updateControls();
                },
                error: function(err) {
                    alert("Invalid password!");
                }
            });
        }

        // Update control visibility
        function updateControls() {
            if (isEditable) {
                $('#lock-button').removeClass('hidden');
                $('#password').addClass('hidden');
                $('#edit-button').addClass('hidden');
            } else {
                $('#lock-button').addClass('hidden');
                $('#password').removeClass('hidden');
                $('#edit-button').removeClass('hidden');
            }
        }

        // Fetch data on page load
        $(document).ready(function() {
            fetchTasks();
            fetchGrid();

            $('#edit-button').click(toggleEditMode);
            $('#lock-button').click(function() {
                toggleEditMode();
                saveGrid();
            });
        });
    </script>
</body>
</html>
"""

if __name__ == '__main__':
    app.run(debug=True)

