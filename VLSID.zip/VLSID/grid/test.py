import torch
print(torch.cuda.is_available())  # Should return True if GPU is available

