from flask import Flask, render_template_string, request, jsonify, Response, redirect, url_for
import cv2
from ultralytics import YOLO
import time
import threading

app = Flask(__name__)

# Camera URL (your MJPEG stream)
CAMERA_URL = "http://192.168.82.160:8080/video"

# Load YOLOv8 model
model = YOLO('best.pt')

# Initialize video capture
cap = cv2.VideoCapture(CAMERA_URL)

# Task Management
tasks = []
task_counter = 1

# Grid Management
GRID_SIZE = 20
grid_state = [['red' for _ in range(GRID_SIZE)] for _ in range(GRID_SIZE)]
is_editable = False


# Add task creation time to handle deletion timing
def add_task_to_list(task_name):
    global task_counter
    task = {'id': task_counter, 'task_name': task_name, 'created_at': time.time()}
    tasks.append(task)
    task_counter += 1


# Auto delete task logic based on creation time
def auto_delete_tasks():
    while True:
        time.sleep(1)
        current_time = time.time()
        tasks_to_delete = [task for task in tasks if current_time - task['created_at'] >= 15]
        for task in tasks_to_delete:
            tasks.remove(task)


# Video stream generator
def generate_frames():
    while True:
        start_time = time.time()
        ret, frame = cap.read()
        if not ret:
            break

        results = model(frame)
        detections = results[0]
        detections = detections[detections.boxes.conf > 0.8]
        frame = detections.plot()

        ret, buffer = cv2.imencode('.jpg', frame)
        if not ret:
            continue

        frame_bytes = buffer.tobytes()

        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')

        elapsed_time = time.time() - start_time
        time.sleep(max(0, 0.2 - elapsed_time))


# HTML Template
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Stream and Editable Grid</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .container { display: flex; }
        .video { margin-right: 20px; }
        .grid-container { display: grid; grid-template-columns: repeat(20, 1fr); width: 500px; height: 500px; border: 1px solid #000; }
        .grid-item { width: 25px; height: 25px; cursor: pointer; }
        .controls, .tasks { margin: 10px 0; }
        button { margin: 5px; padding: 5px 10px; cursor: pointer; }
        .hidden { display: none; }
    </style>
</head>
<body>
    <h1>Live Video Stream and Editable Grid</h1>
    <div class="container">
        <div class="video">
            <h2>Live Video Stream</h2>
            <img src="{{ url_for('video_feed') }}" width="640" height="480">
        </div>
        <div>
            <h2>Task List</h2>
            <form id="task-form">
                <input type="text" name="task" placeholder="Enter new task" required>
                <button type="submit">Add Task</button>
            </form>
            <ul id="task-list"></ul>

            <h2>Editable Grid</h2>
            <div class="controls">
                <button id="edit-button">Edit Grid</button>
                <button id="lock-button" class="hidden">Lock Grid</button>
                <input id="password" type="password" placeholder="Enter password" class="hidden">
            </div>
            <div class="grid-container" id="grid"></div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        let tasks = [];
        let grid = [];
        let isEditable = false;

        function fetchTasks() {
            $.get("/tasks", function(data) {
                tasks = data.tasks;
                renderTasks();
            });
        }

        function fetchGrid() {
            $.get("/get_grid", function(data) {
                grid = data.grid;
                isEditable = data.is_editable;
                renderGrid();
                updateControls();
            });
        }

        function renderTasks() {
            const taskList = $('#task-list');
            taskList.empty();
            tasks.forEach(task => {
                taskList.append(`
                    <li>
                        ${task.task_name}
                        <button onclick="deleteTask(${task.id})">Delete</button>
                    </li>
                `);
            });
        }

        function deleteTask(taskId) {
            $.ajax({
                url: `/delete_task/${taskId}`,
                method: 'DELETE',
                success: fetchTasks
            });
        }

        function renderGrid() {
            const gridContainer = $('#grid');
            gridContainer.empty();
            grid.forEach((row, rowIndex) => {
                row.forEach((cellColor, colIndex) => {
                    gridContainer.append(`
                        <div
                            class="grid-item"
                            style="background-color: ${cellColor};"
                            data-row="${rowIndex}"
                            data-col="${colIndex}"
                            onclick="toggleColor(${rowIndex}, ${colIndex})"
                        ></div>
                    `);
                });
            });
        }

        function toggleColor(row, col) {
            if (!isEditable) return;
            const currentColor = grid[row][col];
            grid[row][col] = currentColor === 'red' ? 'blue' : 'red';
            renderGrid();
        }

        function saveGrid() {
            $.post("/update_grid", JSON.stringify({ grid }), fetchGrid, 'json');
        }

        function toggleEditMode() {
            const password = $('#password').val();
            $.post("/toggle_edit", JSON.stringify({ password }), function(data) {
                isEditable = data.is_editable;
                updateControls();
            }).fail(() => alert("Invalid password!"));
        }

        function updateControls() {
            if (isEditable) {
                $('#lock-button').removeClass('hidden');
                $('#password').addClass('hidden');
                $('#edit-button').addClass('hidden');
            } else {
                $('#lock-button').addClass('hidden');
                $('#password').removeClass('hidden');
                $('#edit-button').removeClass('hidden');
            }
        }

        $(document).ready(function() {
            fetchTasks();
            fetchGrid();

            $('#task-form').on('submit', function(event) {
                event.preventDefault(); // Prevent page reload
                const task = $(this).find('input[name="task"]').val();
                if (task) {
                    $.post("/add_task", { task }, function() {
                        fetchTasks(); // Refresh task list
                        $('#task-form')[0].reset(); // Clear input field
                    });
                }
            });

            $('#edit-button').click(toggleEditMode);
            $('#lock-button').click(() => {
                toggleEditMode();
                saveGrid();
            });

            setInterval(fetchTasks, 3000);
            setInterval(fetchGrid, 3000);
        });
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route('/add_task', methods=['POST'])
def add_task():
    task_name = request.form.get('task')
    if task_name:
        add_task_to_list(task_name)
    return jsonify({'message': 'Task added'})

@app.route('/tasks', methods=['GET'])
def get_tasks():
    return jsonify({'tasks': tasks})

@app.route('/delete_task/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    global tasks
    tasks = [task for task in tasks if task['id'] != task_id]
    return jsonify({'message': 'Task deleted'})

@app.route('/get_grid', methods=['GET'])
def get_grid():
    return jsonify({'grid': grid_state, 'is_editable': is_editable})

@app.route('/update_grid', methods=['POST'])
def update_grid():
    global grid_state
    grid_state = request.json['grid']
    return jsonify({'message': 'Grid updated successfully'})

@app.route('/toggle_edit', methods=['POST'])
def toggle_edit():
    global is_editable
    password = request.json.get('password')
    if password == 'admin':  # Replace 'admin' with your desired password
        is_editable = not is_editable
        return jsonify({'message': 'Edit mode toggled', 'is_editable': is_editable})
    else:
        return jsonify({'message': 'Invalid password'}), 403

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    # Start the auto-delete task thread
    thread = threading.Thread(target=auto_delete_tasks, daemon=True)
    thread.start()
    # Run the Flask app
    app.run(host='0.0.0.0', port=5000, debug=True)

