import onnxruntime
import cv2
import time
import onnx
import numpy as np
from flask import Flask, render_template_string, Response
import torch

# Initialize Flask application
app = Flask(__name__)

# Camera URL (your MJPEG stream)
CAMERA_URL = "http://192.168.82.160:8080/video"

# Load YOLOv5 ONNX model
# Load ONNX model
onnx_model_path = "yolov5s.onnx"  # Update with your ONNX model file path
session = onnxruntime.InferenceSession(onnx_model_path)

# Initialize video capture
cap = cv2.VideoCapture(CAMERA_URL)

# HTML Template for displaying video feed
index_html = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Video Stream with YOLOv5 Detection</title>
</head>
<body>
    <h1>Live Video Stream with YOLOv5 Object Detection</h1>
    <img src="{{ url_for('video_feed') }}" width="640" height="480">
</body>
</html>
"""

# Process video feed and perform object detection
def generate_frames():
    frame_count = 0
    fps = 5  # Process 5 frames per second

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Skip frames to achieve 5 fps (e.g., process every 5th frame)
        if frame_count % (30 // fps) == 0:
            # Preprocess the frame for YOLOv5 ONNX model
            input_frame = preprocess(frame)

            # Run the ONNX model on the frame
            inputs = {session.get_inputs()[0].name: input_frame}
            detections = session.run(None, inputs)[0]

            # Process detections
            for detection in detections[0]:
                # Assuming detections[0] is a list of bounding boxes, we need to adjust this.
                x1, y1, x2, y2, confidence, class_id = detection[:6]  # Adjust if more details exist

                if confidence > 0.2:  # Filter by confidence
                    # Draw bounding box and label
                    cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (255, 0, 0), 2)
                    label = f"Class {int(class_id)}: {confidence:.2f}"
                    cv2.putText(frame, label, (int(x1), int(y1) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)

        # Increment frame count
        frame_count += 1

        # Encode the frame as JPEG
        ret, buffer = cv2.imencode('.jpg', frame)
        if not ret:
            continue

        # Convert the frame to bytes for streaming
        frame_bytes = buffer.tobytes()

        # Yield the frame in the proper format for MJPEG streaming
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')

# Preprocessing function for the ONNX model
def preprocess(frame):
    # Resize and normalize frame as required by your ONNX model
    frame_resized = cv2.resize(frame, (640, 640))  # Resize to input size (640x640 for YOLOv5)
    frame_rgb = cv2.cvtColor(frame_resized, cv2.COLOR_BGR2RGB)  # Convert to RGB
    frame_normalized = frame_rgb.astype(np.float32) / 255.0  # Normalize to [0, 1]
    input_frame = np.transpose(frame_normalized, (2, 0, 1))  # Change to CxHxW
    input_frame = np.expand_dims(input_frame, axis=0)  # Add batch dimension
    return input_frame

@app.route('/')
def index():
    return render_template_string(index_html)  # Render the HTML template

@app.route('/video_feed')
def video_feed():
    # Return the live video feed from the camera, processed by the model
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0", port=5000)

