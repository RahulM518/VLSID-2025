from flask import Flask, Response, render_template_string
import cv2
import torch
import threading

# Flask app
app = Flask(__name__)

# Replace with your IP Webcam URL
CAMERA_URL = "http://192.168.1.100:8080/video"

# Load the YOLOv5 model (replace 'best.pt' with your trained weights file)
model = torch.hub.load('ultralytics/yolov5', 'custom', path='best.pt')  # Load custom trained model

# Global variable to hold the current frame
current_frame = None

def capture_frames():
    global current_frame
    cap = cv2.VideoCapture(CAMERA_URL)
    if not cap.isOpened():
        print("Error: Unable to open video feed.")
        return

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Error: Failed to grab frame.")
            break

        # Convert BGR frame to RGB for YOLO model
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        # Perform object detection
        results = model(rgb_frame)

        # Render detections on the frame
        detections = results.pandas().xyxy[0]  # Get bounding box data as pandas DataFrame
        for _, det in detections.iterrows():
            x1, y1, x2, y2 = int(det['xmin']), int(det['ymin']), int(det['xmax']), int(det['ymax'])
            label = f"{det['name']} ({det['confidence']:.2f})"

            # Draw bounding box
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            # Put label
            cv2.putText(frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        # Encode the frame as JPEG
        _, buffer = cv2.imencode('.jpg', frame)
        current_frame = buffer.tobytes()

@app.route('/video_feed')
def video_feed():
    def generate():
        global current_frame
        while True:
            if current_frame:
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + current_frame + b'\r\n')

    return Response(generate(), mimetype='multipart/x-mixed-replace; boundary=frame')

# HTML template for the live feed
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Live Object Detection</title>
</head>
<body>
    <h1>Live Object Detection</h1>
    <div>
        <img src="/video_feed" alt="Live Feed" width="640" height="480">
    </div>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

if __name__ == '__main__':
    # Start frame capture in a background thread
    frame_thread = threading.Thread(target=capture_frames)
    frame_thread.daemon = True
    frame_thread.start()

    # Run the Flask app
    app.run(host='0.0.0.0', port=5000, debug=True)

