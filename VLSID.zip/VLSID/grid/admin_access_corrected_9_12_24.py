from flask import Flask, render_template_string, request, jsonify, redirect
import time
import threading

app = Flask(__name__)

# Task Management
tasks = []
task_counter = 1

# Grid Management
GRID_SIZE = 20
grid_state = [['red' for _ in range(GRID_SIZE)] for _ in range(GRID_SIZE)]
is_editable = False

# Add task creation time to handle deletion timing
def add_task_to_list(task_name):
    global task_counter
    task = {'id': task_counter, 'task_name': task_name, 'created_at': time.time()}
    tasks.append(task)
    print(f"Added Task: {task_name}")
    print(f"Current Task List: {[task['task_name'] for task in tasks]}")
    task_counter += 1

@app.route('/')
def home():
    # Render the HTML directly from a string
    return render_template_string(HTML_TEMPLATE)

@app.route('/add_task', methods=['POST'])
def add_task():
    task_name = request.form.get('task')
    if task_name:
        add_task_to_list(task_name)
    return redirect('/')

@app.route('/tasks', methods=['GET'])
def get_tasks():
    return jsonify({'tasks': tasks})

@app.route('/delete_task/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    global tasks
    tasks = [task for task in tasks if task['id'] != task_id]
    print(f"Deleted Task ID: {task_id}")
    return jsonify({'message': 'Task deleted successfully'})

# Auto delete task logic based on creation time
def auto_delete_tasks():
    while True:
        time.sleep(1)
        current_time = time.time()
        tasks_to_delete = [task for task in tasks if current_time - task['created_at'] >= 15]  # 15 seconds
        for task in tasks_to_delete:
            tasks.remove(task)
            print(f"Automatically Deleted Task: {task['task_name']}")
        print(f"Current Task List: {[task['task_name'] for task in tasks]}")

# Grid Functions
@app.route('/get_grid', methods=['GET'])
def get_grid():
    return jsonify({'grid': grid_state, 'is_editable': is_editable})

@app.route('/update_grid', methods=['POST'])
def update_grid():
    global grid_state
    grid_state = request.json['grid']
    return jsonify({'message': 'Grid updated successfully'})

@app.route('/toggle_edit', methods=['POST'])
def toggle_edit():
    global is_editable
    password = request.json.get('password')
    if password == 'admin':
        is_editable = not is_editable
        return jsonify({'message': 'Edit mode toggled', 'is_editable': is_editable})
    else:
        return jsonify({'message': 'Invalid password'}), 403

# HTML Template (embedded directly in the Python file)
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Task List and Editable Grid</title>
    <style>
        body { font-family: Arial, sans-serif; }
        ul { list-style-type: none; }
        li { margin: 10px 0; }
        .delete-btn { color: red; cursor: pointer; }
        .grid-container { display: grid; grid-template-columns: repeat(20, 1fr); width: 500px; height: 500px; border: 1px solid #000; }
        .grid-item { width: 25px; height: 25px; cursor: pointer; }
        .controls { margin: 10px 0; }
        button { margin: 5px; padding: 5px 10px; cursor: pointer; }
        .hidden { display: none; }
    </style>
</head>
<body>
    <h1>Task List</h1>
    <form action="/add_task" method="POST">
        <input type="text" name="task" placeholder="Enter new task" required>
        <button type="submit">Add Task</button>
    </form>

    <h2>Current Tasks</h2>
    <ul id="task-list"></ul>

    <h2>Editable Grid</h2>
    <div class="controls">
        <button id="edit-button">Edit Grid</button>
        <button id="lock-button" class="hidden">Lock Grid</button>
        <input id="password" type="password" placeholder="Enter password" class="hidden">
    </div>
    <div class="grid-container" id="grid"></div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        let tasks = [];
        let grid = [];
        let isEditable = false;
        let gridAutoRefreshInterval;

        // Fetch tasks and grid state from server
        function fetchTasks() {
            $.get("/tasks", function(data) {
                tasks = data.tasks;
                renderTasks();
            });
        }

        function fetchGrid() {
            $.get("/get_grid", function(data) {
                grid = data.grid;
                isEditable = data.is_editable;
                renderGrid();
                updateControls();
            });
        }

        // Render task list
        function renderTasks() {
            const taskList = $('#task-list');
            taskList.empty();
            tasks.forEach(task => {
                taskList.append(`
                    <li>
                        ${task.task_name}
                        <button class="delete-btn" onclick="deleteTask(${task.id})">Delete</button>
                    </li>
                `);
            });
        }

        // Add and delete tasks
        $('#add-task').click(function() {
            const taskInput = $('#task-input');
            const task = taskInput.val();
            if (task) {
                $.post("/add_task", {task: task}, function(data) {
                    fetchTasks();
                    taskInput.val('');
                });
            }
        });

        function deleteTask(taskId) {
            $.ajax({
                url: `/delete_task/${taskId}`,
                method: 'DELETE',
                success: function() {
                    fetchTasks();
                }
            });
        }

        // Render grid
        function renderGrid() {
            const gridContainer = $('#grid');
            gridContainer.empty();
            grid.forEach((row, rowIndex) => {
                row.forEach((cellColor, colIndex) => {
                    gridContainer.append(`
                        <div
                            class="grid-item"
                            style="background-color: ${cellColor};"
                            data-row="${rowIndex}"
                            data-col="${colIndex}"
                            onclick="toggleColor(${rowIndex}, ${colIndex})"
                        ></div>
                    `);
                });
            });
        }

        // Toggle cell color
        function toggleColor(row, col) {
            if (!isEditable) return;

            const currentColor = grid[row][col];
            grid[row][col] = currentColor === 'red' ? 'blue' : 'red';
            renderGrid();
        }

        // Save grid state
        function saveGrid() {
            $.ajax({
                url: '/update_grid',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ grid }),
                success: function() {
                    console.log("Grid saved successfully!");
                }
            });
        }

        // Edit mode toggle
        function toggleEditMode() {
            const password = $('#password').val();
            $.ajax({
                url: '/toggle_edit',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ password }),
                success: function(data) {
                    isEditable = data.is_editable;
                    updateControls();
                    if (isEditable) {
                        // Stop auto-refreshing grid when in edit mode
                        clearInterval(gridAutoRefreshInterval);
                    } else {
                        // Restart grid auto-refresh
                        gridAutoRefreshInterval = setInterval(fetchGrid, 3000);
                    }
                },
                error: function(err) {
                    alert("Invalid password!");
                }
            });
        }

        // Update control visibility
        function updateControls() {
            if (isEditable) {
                $('#lock-button').removeClass('hidden');
                $('#password').addClass('hidden');
                $('#edit-button').addClass('hidden');
            } else {
                $('#lock-button').addClass('hidden');
                $('#password').removeClass('hidden');
                $('#edit-button').removeClass('hidden');
            }
        }

        // Fetch data on page load
        $(document).ready(function() {
            fetchTasks();
            fetchGrid();

            $('#edit-button').click(toggleEditMode);
            $('#lock-button').click(function() {
                toggleEditMode();
                saveGrid();
            });

            // Auto-refresh tasks every 3 seconds
            setInterval(fetchTasks, 3000);

            // Auto-refresh grid every 3 seconds (but controlled during editing)
            gridAutoRefreshInterval = setInterval(fetchGrid, 3000);
        });
    </script>
</body>
</html>
"""

if __name__ == '__main__':
    import threading
    # Start a background thread to auto-delete tasks every second
    thread = threading.Thread(target=auto_delete_tasks)
    thread.daemon = True
    thread.start()
    app.run(host='0.0.0.0', port=5000, debug=True)

