from flask import Flask, Response, render_template_string
import cv2
import threading

app = Flask(__name__)

# Replace with your phone's IP Webcam URL
CAMERA_URL = "http://192.168.82.160:8080/video"

# Global variable to hold the current frame
current_frame = None


def capture_frames():
    global current_frame
    cap = cv2.VideoCapture(CAMERA_URL)
    while True:
        ret, frame = cap.read()
        if ret:
            # Encode frame as JPEG
            _, buffer = cv2.imencode('.jpg', frame)
            current_frame = buffer.tobytes()


@app.route('/video_feed')
def video_feed():
    def generate_frame():
        global current_frame
        while True:
            if current_frame:
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + current_frame + b'\r\n')

    return Response(generate_frame(), mimetype='multipart/x-mixed-replace; boundary=frame')


# HTML template with embedded video
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Live Camera Feed</title>
</head>
<body>
    <h1>Live Camera Feed</h1>
    <div>
        <img src="/video_feed" alt="Live Feed" width="640" height="480">
    </div>
</body>
</html>
"""

@app.route('/')
def home():
    return render_template_string(HTML_TEMPLATE)


if __name__ == '__main__':
    # Start the frame capture in a background thread
    frame_thread = threading.Thread(target=capture_frames)
    frame_thread.daemon = True
    frame_thread.start()

    app.run(host='0.0.0.0', port=5000, debug=True)

