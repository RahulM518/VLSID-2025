from flask import Flask, render_template_string, Response
import cv2
import torch

# Initialize Flask application
app = Flask(__name__)

# Camera URL (your MJPEG stream)
CAMERA_URL = "http://192.168.82.160:8080/video"

# Load YOLOv5 model
# Here, 'yolov5s' is a small, fast model, but you can replace it with any other model as required.
model = torch.hub.load('ultralytics/yolov5', 'yolov5s')  # Load YOLOv5 small model

# Initialize video capture
cap = cv2.VideoCapture(CAMERA_URL)

# HTML Template for displaying video feed
index_html = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Live Video Stream with YOLOv5 Detection</title>
</head>
<body>
    <h1>Live Video Stream with YOLOv5 Object Detection</h1>
    <img src="{{ url_for('video_feed') }}" width="640" height="480">
</body>
</html>
"""

def generate_frames():
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        # Perform object detection
        results = model(frame)  # Run the model on the frame
        
        # Render results on the frame
        frame = results.render()[0]  # Draw boxes and labels on the frame
        
        # Encode the frame as JPEG
        ret, buffer = cv2.imencode('.jpg', frame)
        if not ret:
            continue
        
        # Convert the frame to bytes for streaming
        frame_bytes = buffer.tobytes()

        # Yield the frame in the proper format for MJPEG streaming
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')

@app.route('/')
def index():
    return render_template_string(index_html)  # Render the HTML template

@app.route('/video_feed')
def video_feed():
    # Return the live video feed from the camera, processed by the model
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0", port=5000)

