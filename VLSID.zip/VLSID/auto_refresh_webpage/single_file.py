from flask import Flask, render_template_string, request, jsonify, redirect
import time
import threading

app = Flask(__name__)

# Sample task data structure to store tasks
tasks = []
task_counter = 1

# Add task creation time to handle deletion timing
def add_task_to_list(task_name):
    global task_counter
    task = {'id': task_counter, 'task_name': task_name, 'created_at': time.time()}
    tasks.append(task)
    print(f"Added Task: {task_name}")
    print(f"Current Task List: {[task['task_name'] for task in tasks]}")
    task_counter += 1

@app.route('/')
def home():
    # Render the HTML directly from a string
    return render_template_string(HTML_TEMPLATE)

@app.route('/add_task', methods=['POST'])
def add_task():
    task_name = request.form.get('task')
    if task_name:
        add_task_to_list(task_name)
    return redirect('/')

@app.route('/tasks', methods=['GET'])
def get_tasks():
    return jsonify({'tasks': tasks})

@app.route('/delete_task/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    global tasks
    tasks = [task for task in tasks if task['id'] != task_id]
    print(f"Deleted Task ID: {task_id}")
    return jsonify({'message': 'Task deleted successfully'})

# Auto delete task logic based on creation time
def auto_delete_tasks():
    while True:
        time.sleep(1)
        current_time = time.time()
        tasks_to_delete = [task for task in tasks if current_time - task['created_at'] >= 15]  # 15 seconds
        for task in tasks_to_delete:
            tasks.remove(task)
            print(f"Automatically Deleted Task: {task['task_name']}")
        print(f"Current Task List: {[task['task_name'] for task in tasks]}")

# HTML Template (embedded directly in the Python file)
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Task List</title>
    <style>
        body { font-family: Arial, sans-serif; }
        ul { list-style-type: none; }
        li { margin: 10px 0; }
        .delete-btn { color: red; cursor: pointer; }
    </style>
</head>
<body>
    <h1>Task List</h1>
    <form action="/add_task" method="POST">
        <input type="text" name="task" placeholder="Enter new task" required>
        <button type="submit">Add Task</button>
    </form>

    <h2>Current Tasks</h2>
    <ul id="task-list"></ul>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        let tasks = [];

        // Fetch tasks from the server and update the HTML dynamically
        function fetchTasks() {
            $.get("/tasks", function(data) {
                tasks = data.tasks;
                renderTasks();
            });
        }

        function renderTasks() {
            const taskList = $('#task-list');
            taskList.empty();  // Clear the list first
            tasks.forEach(task => {
                taskList.append(
                    `<li>Task: ${task.task_name} <button class="delete-btn" onclick="deleteTask(${task.id})">Delete</button></li>`
                );
            });
        }

        // Function to delete a task
        function deleteTask(taskId) {
            $.ajax({
                url: `/delete_task/${taskId}`,
                type: 'DELETE',
                success: function() {
                    fetchTasks();  // Refresh the task list on successful deletion
                }
            });
        }

        // Fetch tasks every 3 seconds
        setInterval(fetchTasks, 500);

        // Fetch tasks when the page loads
        $(document).ready(fetchTasks);
    </script>
</body>
</html>
"""

if __name__ == '__main__':
    import threading
    # Start a background thread to auto-delete tasks every second
    thread = threading.Thread(target=auto_delete_tasks)
    thread.daemon = True
    thread.start()
    app.run(host='0.0.0.0', port=5000, debug=True)
