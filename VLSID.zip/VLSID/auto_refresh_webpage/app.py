from flask import Flask, render_template, request, jsonify, redirect
import time
import threading

app = Flask(__name__)

# Sample task data structure to store tasks
tasks = []
task_counter = 1

# Add task creation time to handle deletion timing
def add_task_to_list(task_name):
    global task_counter
    task = {'id': task_counter, 'task_name': task_name, 'created_at': time.time()}
    tasks.append(task)
    print(f"Added Task: {task_name}")
    print(f"Current Task List: {[task['task_name'] for task in tasks]}")
    task_counter += 1

@app.route('/')
def home():
    return render_template('home.html')  # Render the HTML template

@app.route('/add_task', methods=['POST'])
def add_task():
    task_name = request.form.get('task')
    if task_name:
        add_task_to_list(task_name)
    return redirect('/')

@app.route('/tasks', methods=['GET'])
def get_tasks():
    return jsonify({'tasks': tasks})

@app.route('/delete_task/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    global tasks
    tasks = [task for task in tasks if task['id'] != task_id]
    print(f"Deleted Task ID: {task_id}")
    return jsonify({'message': 'Task deleted successfully'})

# Auto delete task logic based on creation time
def auto_delete_tasks():
    while True:
        time.sleep(1)
        current_time = time.time()
        tasks_to_delete = [task for task in tasks if current_time - task['created_at'] >= 15]  # 15 seconds
        for task in tasks_to_delete:
            tasks.remove(task)
            print(f"Automatically Deleted Task: {task['task_name']}")
        print(f"Current Task List: {[task['task_name'] for task in tasks]}")

if __name__ == '__main__':
    import threading
    # Start a background thread to auto-delete tasks every second
    thread = threading.Thread(target=auto_delete_tasks)
    thread.daemon = True
    thread.start()
    app.run(debug=True)

